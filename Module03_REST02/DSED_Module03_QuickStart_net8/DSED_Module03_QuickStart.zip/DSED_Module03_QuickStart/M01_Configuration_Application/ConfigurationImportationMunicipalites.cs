namespace M01_Configuration_Application
{
  public class ConfigurationImportationMunicipalites
  {
    public string Mode { get; set; } = string.Empty; // options: local, http
    public string Uri { get; set; } = string.Empty;
  }
}