﻿namespace M01_Entite
{
    public interface IDepotImportationMunicipalites
    {
        IEnumerable<Municipalite> LireMunicipalites();
    }
}
